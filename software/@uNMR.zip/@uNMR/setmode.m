function setmode(obj,txmode,rxmode)
% set the ASIC mode
% normal NMR : txmode = 1; rxmode =1;
% tuning : 
%