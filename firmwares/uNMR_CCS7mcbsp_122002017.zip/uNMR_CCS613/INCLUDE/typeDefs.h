/*
 * typeDefs.h
 *
 *  Created on: Jul 29, 2016
 *      Author: mccowan1
 */
//###########################################################################
// Revision History:
//
//
//
//
//
//###########################################################################

#ifndef INCLUDE_TYPEDEFS_H_
#define INCLUDE_TYPEDEFS_H_

#include "DSP2833x_Device.h"

typedef unsigned char	Uint8;
typedef char    		int8;


#endif /* INCLUDE_TYPEDEFS_H_ */
