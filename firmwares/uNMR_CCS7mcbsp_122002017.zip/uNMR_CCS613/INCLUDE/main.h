/*
 * main.h
 *
 *  Created on: Mar 14, 2014
 *      Author:
 */
//###########################################################################
// Revision History:
//
//
//
//
//
//###########################################################################

#ifndef INCLUDE_MAIN_H_
#define INCLUDE_MAIN_H_
#include "typeDefs.h"
#include "DSP28x_Project.h"     			// Device Headerfile and Examples Include File

	#include "DSP2833x_Adc.h"
//	#include "DSP2833x_Clk.h"
//	#include "DSP2833x_Comp.h"
//	#include "DSP2833x_Flash.h"
	#include "DSP2833x_Gpio.h"
//	#include "DSP2833x_Pie.h"
//	#include "DSP2833x_Pll.h"
//	#include "DSP2833x_Pwm.h"
	#include "DSP2833x_Sci.h"
	#include "DSP2833x_Spi.h"
//	#include "DSP2833x_Timer.h"
//	#include "DSP2833x_Wdog.h"
	//#include "IQmathLib.h"

	#include "mb.h"
//	#include "initialization.h"
//	#include "isr.h"



#endif /* INCLUDE_MAIN_H_ */
