/*
 * ADS1248 .c
 *
 *  Created on: Mar 14, 2017
 *      Author: mccowan1
 */




